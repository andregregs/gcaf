<aside>
	<h1>Solutions</h1>
	<div class="list">
		<div class="item">
			<a href="?lab=gsp1089">Skill Badges</a>
		</div>
		<div class="item">
			<a href="?lab=gsp361">Labs</a>
		</div>
	</div>
</aside>

<style>
	aside {
		width: 100%;
		height: 100%;
		box-shadow: 0 0 0.5rem #ccc;
		padding: 2.5% 1rem;
	}

	.list {
		margin-top: 1rem;
	}
	.item {
		padding: 1rem;
		border-bottom: 1px solid #ccc;
		transition: background 0.25s;
	}
	.item:first-child {
		border-top: 1px solid #ccc;
	}
	.item:hover {
		background-color: #f0f0f0;
	}
</style>
