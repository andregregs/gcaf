# GOOGLE CLOUD SKILL BOOST AUTOMATION

> **PLEASE NOTE:** If you are unfamiliar with Google Cloud Platform environments or any of the required programming languages and tools below, please consider **NOT USING THIS**!
> Because there's a lot of effort required to prepare your computer before you can run this tool properly, it's important to understand what you're doing first. Therefore, I highly recommend following the lab instructions and learning more for a better understanding.

## REQUIREMENT

1. Brain 🗿

## HOW TO USE?

Each lab covers different topics and steps, so not all labs are supported by this tool. Please review the steps inside each categorized folder to determine the applicable solutions, as follows:

-   [genai-chat](./genai-chat/) for Generative AI Chat Labs
-   [sdk-scripts](./sdk-scripts/) for labs that can be completed using Google Cloud SDK
-   Looker for Looker studio labs
