# GCS static website bucket

This module provisions Cloud Storage buckets configured for static website hosting.
