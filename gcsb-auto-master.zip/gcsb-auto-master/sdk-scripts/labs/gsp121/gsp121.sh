echo "${BG_MAGENTA}${BOLD}Starting Execution${RESET}"

gcloud source repos create REPO_DEMO --project $PROJECT_ID

echo "${BG_RED}${BOLD}Congratulations For Completing The Lab !!!${RESET}"